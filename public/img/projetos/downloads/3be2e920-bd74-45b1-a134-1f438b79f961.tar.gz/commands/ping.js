const { MessageEmbed } = require("discord.js");

module.exports = {
  info: {
    name: "ping",
    description: "",
    usage: "[ping]",
    aliases: ["pong", "ms", "ping"],
  },

  run: async function (client, message, args) {
    let embed = new MessageEmbed()
      .setAuthor("Gamma", "http://gammabot.xyz/img/gamma.png")
      .setDescription(`Latency is **${Date.now() - message.createdTimestamp}ms**\nAPI Latency is **${Math.round(client.ws.ping)}ms**`)
      .setFooter("https://gammabot.xyz/")
      .setColor("RED")
    return message.channel.send(embed);
  }
};