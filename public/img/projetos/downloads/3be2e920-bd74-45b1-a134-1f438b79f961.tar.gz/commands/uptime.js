const { MessageEmbed } = require("discord.js");

module.exports = {
  info: {
    name: "uptime",
    description: "",
    usage: "[uptime]",
    aliases: ["up", "uptime", "tempo", "online"],
  },

  run: async function (client, message, args) {
  let totalSeconds = client.uptime / 1000;
  let days = Math.floor(totalSeconds / 86400);
  let hours = Math.floor(totalSeconds / 3600);
  totalSeconds %= 3600;
  let minutes = Math.floor(totalSeconds / 60);
  let seconds = totalSeconds % 60;

  let uptime = `🕗 ${days.toFixed()} Days\n🕗 ${hours.toFixed()} Hours\n🕗 ${minutes.toFixed()} Minutes\n🕗 ${seconds.toFixed()} Seconds`;

  let embed = new MessageEmbed()
    .setAuthor("Gamma", "http://gammabot.xyz/img/gamma.png")
    .setThumbnail("https://cdn.dribbble.com/users/319192/screenshots/1551362/2-and-a-half-hours.gif")
    .setColor("RED")
    .setDescription(`**Gamma Uptime:**\n${uptime}`)
    .setFooter("https://gammabot.xyz/")

  return message.channel.send(embed);
  }
};