const { MessageEmbed } = require("discord.js");

module.exports = {
  info: {
    name: "help",
    description: "To add/invite the bot to your server",
    usage: "[invite]",
    aliases: ["commands", "help me", "pls help", "ajuda"],
  },

  run: async function (client, message, args) {

    let invite = new MessageEmbed()
      .setAuthor("Gamma Help", "http://gammabot.xyz/img/gamma.png")
      .setDescription("Gamma is a discord bot that plays music from youtube on discord calls!\n\nThe best discord bot to play youtube music on discord. You just need to add it and give the command .play <song_name>\n\n:white_check_mark: [Click here](https://gammabot.xyz/commands) for a list of commands\n\n:envelope_with_arrow: Gamma can be added to as many servers as you want! [Click here](https://gammabot.xyz/invite)\n\n:question: New to Gamma? Check out our [FAQ](https://gammabot.xyz/faq)\n\n:moneybag: Donate to Gamma by [Click here](https://gammabot.xyz/donate), it will help us a lot\n\n:page_facing_up: Still need help? [Click here](https://gammabot.xyz/server) to join our Discord server")
      .setColor("#2F3136")
    return message.channel.send(invite);
  },
};