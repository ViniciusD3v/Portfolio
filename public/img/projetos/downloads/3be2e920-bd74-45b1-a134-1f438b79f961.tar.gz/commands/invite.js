const { MessageEmbed } = require("discord.js");

module.exports = {
  info: {
    name: "invite",
    description: "To add/invite the bot to your server",
    usage: "[invite]",
    aliases: ["invite", "links", "social"],
  },

  run: async function (client, message, args) {

    let invite = new MessageEmbed()
      .setAuthor("Links!", "http://gammabot.xyz/img/gamma.png")
      .setDescription(`[Commands](https://gammabot.xyz/commands)\n[Official Discord](https://gammabot.xyz/server)\n[Add Me](https://gammabot.xyz/invite)\n[Donate](https://gammabot.xyz/donate)\n[Top.gg](https://top.gg/bot/765581943479730187)`)
      .setColor("#2F3136")
    return message.channel.send(invite);
  },
};