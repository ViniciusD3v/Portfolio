const { MessageEmbed } = require("discord.js");

module.exports = {
  info: {
    name: "botinfo",
    description: "botinfo",
    usage: "[botinfo]",
    aliases: ["info"],
  },

  run: async function (client, message, args) {

    let invite = new MessageEmbed()
      .setAuthor("About Gamma", "http://gammabot.xyz/img/gamma.png")
      .setDescription("Gamma is an experienced 🎵 bot that has a ton of features you will enjoy! Use ``.help`` to see all the Commands. My creator and **Raggzinn#4759**" + `\n[Commands](https://gammabot.xyz/commands)\n[Official Discord](https://gammabot.xyz/server)\n[Add Me](https://gammabot.xyz/invite)\n[Donate](https://gammabot.xyz/donate)\n[Top.gg](https://top.gg/bot/765581943479730187)`)
      .setColor("#2F3136")
    return message.channel.send(invite);
  },
};