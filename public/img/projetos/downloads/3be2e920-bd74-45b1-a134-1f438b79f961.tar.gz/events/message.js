const { MessageEmbed } = require("discord.js");
module.exports = async (client, message) => {
  if (message.author.bot) return;

if(message.content.startsWith(`<@!${client.user.id}>`) || message.content.startsWith(`<@${client.user.id}>`)) {
	var dcprtsb = ("`");
    let embed = new MessageEmbed()
      .setAuthor("Gamma", "http://gammabot.xyz/img/gamma.png")
      .setDescription(`Hello 👋 my prefix currently on this server and ${dcprtsb}.${dcprtsb} to know my commands use ${dcprtsb}.help${dcprtsb}`)
      .setFooter("https://gammabot.xyz/")
      .setColor("#2F3136")
    return message.channel.send(embed);
}

  const prefixMention = new RegExp(`^<@!?${client.user.id}> `),
   db = require('quick.db')
   
  let pref = db.get(`prefix.${message.guild.id}`);
  let prefix;
  
  if (!pref) {
    prefix = message.content.match(prefixMention) ? message.content.match(prefixMention)[0] : client.config.prefix;
  } else {
    prefix = pref;
  }
  

  if (message.content.indexOf(prefix) !== 0) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();

  const cmd = client.commands.get(command);
  const aliases = client.commands.find(x => x.info.aliases.includes(command))

process.on("unhandledRejection", (reason, promise) => {
    try {
        console.error("Unhandled Rejection at: ", promise, "reason: ", reason.stack || reason);
    } catch {
        console.error(reason);
    }
});
require('events').EventEmitter.defaultMaxListeners = 25

  if(cmd){
    cmd.run(client, message, args);
  }else if(aliases){
    aliases.run(client, message, args);
  }else return
};