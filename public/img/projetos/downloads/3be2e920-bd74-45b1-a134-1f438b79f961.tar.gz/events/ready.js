module.exports = async (client) => {
  console.log("Ligado!");
  await client.user.setActivity("https://gammabot.xyz | .play", {
    type: "PLAYING",
  });
};